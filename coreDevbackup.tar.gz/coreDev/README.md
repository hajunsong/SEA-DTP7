
coreDev:
   This project is for the development of a custom controller
   based on the coreServer 
   You can access the rich set of functions of the coreServer with this libray
   coreCUI helps how to build the project and use the library
   

backup & upgrade format
corecon format : corecon.tar.gz			copy path : /mnt/mtd5
master format : decmaster.tar.gz		copy path : /ecat
disk path : top path
