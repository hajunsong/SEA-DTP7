#ifndef DEVTYPE_H
#define DEVTYPE_H


#define DEV_PCLINUX 1
#define DEV_PCWIN   2
#define DEV_ANDROID 3
#define DEV_DTP7    4
#define DEV_DTP10   5

//#define DEV_TYPE    DEV_PCLINUX


#endif // DEVTYPE_H

