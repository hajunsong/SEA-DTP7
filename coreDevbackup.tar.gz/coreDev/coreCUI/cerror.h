#ifndef CERROR
#define CERROR

#define CUI_ERR_NOT_TC_MODE     "It isn't 'Teaching Mode' Now"
#define CUI_ERR_NOT_RT_MODE     "It isn't 'Repeat Mode' Now"
#define CUI_ERR_NOT_INPUTTED    "You did't input param"
#define CUI_ERR_NOT_REPORTED    "Server NG (check Login, data, ...)"

#endif // CERROR

