###Readme

# CNRoboApi
<br>
 - coreServer와 연결되는 CNRobo API에 대한 Manual입니다, cnroboapi 디렉토리에 있는 CNROboApi.html을 실행하여 manual을 볼 수 있습니다.
# CUIApi
<br>
 - coreCon과 연결되는 CUIApi에 대한 Manual입니다, cuiapi 디렉토리에 있는 CUIApi.html을 실행하여 manual을 볼 수 있습니다.
# Doc
<br>
 - CL Programming manaul, coreCon settings manaul, coreDev API Manual에 대한 pdf file입니다. <br>
 - coreDev API에 대한 manual의 경우 coreDev 구조에 대한 설명이 있습니다.
 - API 사용에 대한 자세한 설명은 CNRoboAPi 혹은 CUIApi를 참고해야합니다.