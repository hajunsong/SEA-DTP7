var searchData=
[
  ['holdprogram',['holdProgram',['../classCUIApp.html#a800f6928aa302c9898282b33d6f67063',1,'CUIApp']]]
];
