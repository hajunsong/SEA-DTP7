var searchData=
[
  ['ma_5fgetarmorder',['MA_getArmOrder',['../classCUIApp.html#a6e584251c583f2faa46c8edb5a2c5a6f',1,'CUIApp']]],
  ['ma_5fgetarmsize',['MA_getArmSize',['../classCUIApp.html#a03be3a483fe4e7bc66b0901a371e5844',1,'CUIApp']]],
  ['ma_5fgethint',['MA_getHint',['../classCUIApp.html#a76041e3a86c423e0572d94c72f74f1fc',1,'CUIApp']]],
  ['ma_5fgetmasterarm',['MA_getMasterArm',['../classCUIApp.html#a0be596e95462c8988c11610db06d2df7',1,'CUIApp']]],
  ['ma_5fsetarmorder',['MA_setArmOrder',['../classCUIApp.html#a0bc1523ac0f460af9466c3f946c43cc4',1,'CUIApp']]],
  ['ma_5fsethint',['MA_setHint',['../classCUIApp.html#a088315a031f6ac9968c2c59c3cd9bfb7',1,'CUIApp']]],
  ['ma_5fsetmasterarm',['MA_setMasterArm',['../classCUIApp.html#a6b8a73f6e2c11b4b6a9b0694430d28c4',1,'CUIApp']]],
  ['movetohome',['moveToHome',['../classCUIApp.html#ae4246ee91a5f098604d03d8459f1b634',1,'CUIApp']]],
  ['movetoposition',['moveToPosition',['../classCUIApp.html#a44cdd21e80259e4718a443737e881cc1',1,'CUIApp']]],
  ['movetoposition2',['moveToPosition2',['../classCUIApp.html#ae6fb6a202f9d1a189c093eeb5e4ad4a9',1,'CUIApp']]]
];
