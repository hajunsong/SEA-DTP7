var searchData=
[
  ['value_5ft',['value_t',['../unioncui__variant__t_1_1value__t.html',1,'cui_variant_t']]]
];
