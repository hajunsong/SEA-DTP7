var searchData=
[
  ['unlock',['unlock',['../classCNRobo.html#a499d243b701b84bc85717fcb8ad5e6d5',1,'CNRobo']]],
  ['update_20history',['update history',['../update_history.html',1,'']]]
];
