var searchData=
[
  ['zeroing',['zeroing',['../classCNRobo.html#add70ad17aea1f65e7d44de4af3627457',1,'CNRobo']]],
  ['zeroingcount',['zeroingCount',['../classCNRobo.html#a6403dc94372721ac2c8959242173950a',1,'CNRobo']]]
];
